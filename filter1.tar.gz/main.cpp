#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <vector>       // std::vector
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv)
{
    if(argc != 2)
    {
        printf("use >> ./filter1 image\n");
        exit(1);
    }
    else
    {
        cv::Mat bgr_image = cv::imread(argv[1]);
        //cv::namedWindow("image original", 0);
        //cv::namedWindow("image CLAHE", 0);
        char text[128];
        if(!bgr_image.empty())
        {
            // READ RGB color image and convert it to Lab
            //cv::Mat bgr_image = cv::imread("seacon/1.jpg");
            cv::Mat lab_image;
            cv::cvtColor(bgr_image, lab_image, CV_BGR2Lab);

            // Extract the L channel
            std::vector<cv::Mat> lab_planes(3);
            cv::split(lab_image, lab_planes);  // now we have the L image in lab_planes[0]

            // apply the CLAHE algorithm to the L channel
            cv::Ptr<cv::CLAHE> clahe = cv::createCLAHE();
            clahe->setClipLimit(3);
            cv::Mat dst;
            clahe->apply(lab_planes[0], dst);

            // Merge the the color planes back into an Lab image
            dst.copyTo(lab_planes[0]);
            cv::merge(lab_planes, lab_image);

           // convert back to RGB
           cv::Mat image_clahe;
           cv::cvtColor(lab_image, image_clahe, CV_Lab2BGR);

           // display the results  (you might also want to see lab_planes[0] before and after).
           //cv::imshow("image original", bgr_image);
           //cv::imshow("image CLAHE", image_clahe);
           sprintf(text, "retifi_%s", argv[1]);
           imwrite( text, image_clahe );

           //cv::waitKey(0);
        }
        else
            printf("ERROR open image file\n");

        return 0;
    }

}
